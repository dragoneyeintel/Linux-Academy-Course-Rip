# NOOT NOOT v2.2 Fixed Duplicate Downloads = Actually Works :p & Removed Some Extraneous Imports / Duplicate Drivers = Faster & Kill Threads = Space Save
# THREADS do not work parallel yet
import time
import threading
import requests
import math
import re
import os
import psutil
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from collections import OrderedDict
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from multiprocessing import *
from itertools import repeat


THREADS = 5
WEBDRIVER_PATH = "C:/Users/Nick3214/Desktop/Courses/courseRip/geckodriver.exe"
PROFILE_PATH = "C:/Users/Nick3214/AppData/Roaming/Mozilla/Firefox/Profiles/076ituj0.default-release"


def download(links):
    print(str(THREADS) + " Threads - " + str(math.ceil(len(links) / THREADS)) + " Links Per Thread\n")
    with ThreadPoolExecutor(max_workers=THREADS) as executor:
        n = 0
        for lnk in links:
            executor.submit(runthread, n, lnk)
            n += 1


def kill():
    # Kill
    PROCNAME = "geckodriver"  # or chromedriver or iedriverserver
    for proc in psutil.process_iter():
        # check whether the process name matches
        if proc.name() == PROCNAME:
            proc.kill()
    print("Killed Rogue Drivers :)")
    killfox()


def killfox():
    PROCNAME = "firefox"
    for proc in psutil.process_iter():
        # check whether the process name matches
        if proc.name() == PROCNAME:
            proc.kill()
    print("Killed Firefox :)")


def runthread(simplecnt, lnk):
    driver = spawndriver()
    print("Spawned Instance " + str(simplecnt + 1))
    driver.get('https://learn.acloud.guru/' + lnk)
    try:
        element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located(
                (By.XPATH, "/html/body/div[1]/div/div[2]/div/main/div/div/div/div[2]/div[1]/video"))
        )
    except:
        return 0
    finally:
        time.sleep(1)
        response = BeautifulSoup(driver.page_source, 'html.parser')
        URL_REGEX = re.compile("(https://content.acloud.guru/[^\"]*)")
        link = re.findall(URL_REGEX, str(response))
        link = link[0].replace(';', '&')
        print(str(link) + "\n")

        with requests.get(link, stream=True) as r:
            r.raise_for_status()
            with open((str(simplecnt + 1) + ".mp4"), 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
    driver.quit()


def spawndriver():
    profile = webdriver.FirefoxProfile(PROFILE_PATH)
    profile.set_preference("network.http.pipelining", True)
    profile.set_preference("network.http.proxy.pipelining", True)
    profile.set_preference("network.http.pipelining.maxrequests", 8)
    profile.set_preference("content.notify.interval", 500000)
    profile.set_preference("content.notify.ontimer", True)
    profile.set_preference("content.switch.threshold", 250000)
    profile.set_preference("browser.cache.memory.capacity", 65536)  # Increase the cache capacity.
    profile.set_preference("browser.startup.homepage", "about:blank")
    profile.set_preference("reader.parse-on-load.enabled", False)  # Disable reader, we won't need that.
    profile.set_preference("browser.pocket.enabled", False)  # Duck pocket too!
    profile.set_preference("loop.enabled", False)
    profile.set_preference("browser.chrome.toolbar_style", 1)  # Text on Toolbar instead of icons
    profile.set_preference("browser.display.show_image_placeholders",
                           False)  # Don't show thumbnails on not loaded images.
    profile.set_preference("browser.display.use_document_colors", False)  # Don't show document colors.
    profile.set_preference("browser.display.use_document_fonts", 0)  # Don't load document fonts.
    profile.set_preference("browser.display.use_system_colors", True)  # Use system colors.
    profile.set_preference("browser.formfill.enable", False)  # Autofill on forms disabled.
    profile.set_preference("browser.helperApps.deleteTempFileOnExit", True)  # Delete temporary files.
    profile.set_preference("browser.shell.checkDefaultBrowser", False)
    profile.set_preference("browser.startup.homepage", "about:blank")
    profile.set_preference("browser.startup.page", 0)  # blank
    profile.set_preference("browser.tabs.forceHide", True)  # Disable tabs, We won't need that.
    profile.set_preference("browser.urlbar.autoFill", False)  # Disable autofill on URL bar.
    profile.set_preference("browser.urlbar.autocomplete.enabled", False)  # Disable autocomplete on URL bar.
    profile.set_preference("browser.urlbar.showPopup", False)  # Disable list of URLs when typing on URL bar.
    profile.set_preference("browser.urlbar.showSearch", False)  # Disable search bar.
    profile.set_preference("extensions.checkCompatibility", False)  # Addon update disabled
    profile.set_preference("extensions.checkUpdateSecurity", False)
    profile.set_preference("extensions.update.autoUpdateEnabled", False)
    profile.set_preference("extensions.update.enabled", False)
    profile.set_preference("general.startup.browser", False)
    profile.set_preference("plugin.default_plugin_disabled", False)
    profile.set_preference("permissions.default.image", 2)  # Image load disabled again
    options = Options()
    options.add_argument("start-maximized")
    options.add_argument("disable-infobars")
    options.add_argument("--disable-extensions")
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-application-cache')
    options.add_argument('--disable-gpu')
    options.add_argument("--disable-dev-shm-usage")
    options.headless = True
    return webdriver.Firefox(options=options, executable_path=WEBDRIVER_PATH, firefox_profile=profile)


class LinuxAcademy:
    def __init__(self):
        # Eg. b74c026d-0a03-4d34-a641-e544cba4fd41
        name = input("Insert Course Name: ")

        self.driver = spawndriver()
        print("Spawned Driver!")
        self.driver.get('https://learn.acloud.guru/course/' + name + '/dashboard')

        try:
            element = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.XPATH,
                                                "/html/body/div[1]/div/div[2]/section/div[2]/div/div[2]/div[1]/div/div[2]/div[2]/a[1]/div/div[1]/span"))
            )
        finally:
            time.sleep(5)
            response = BeautifulSoup(self.driver.page_source, 'html.parser')
            # print(response.prettify())
            URL_REGEX = re.compile("/(course/[^\"]*)")
            links = re.findall(URL_REGEX, str(response))

            # Remove Dup
            remdup = OrderedDict.fromkeys(links)
            finallink = []
            for lnk in remdup:
                if "watch" in lnk:
                    finallink.append(lnk)
            print("Crawled " + str(len(finallink)) + " Links!")
            self.driver.quit()
            download(finallink)

kill()
LinuxAcademy()
