#NOOT NOOT
import time
import requests
import re
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities


class LinuxAcademy:
    def __init__(self):
    # Eg. b74c026d-0a03-4d34-a641-e544cba4fd41
        name = input("Insert Course Name: ")

        profile = webdriver.FirefoxProfile('C:/Users/Nick3214/AppData/Roaming/Mozilla/Firefox/Profiles/076ituj0.default-release')
        profile.set_preference("dom.webdriver.enabled", False)
        profile.set_preference('useAutomationExtension', False)
        profile.update_preferences()
        desired = DesiredCapabilities.FIREFOX

        self.driver = webdriver.Firefox(executable_path="C:/Users/Nick3214/Desktop/Courses/courseRip/geckodriver.exe", firefox_profile=profile, desired_capabilities=desired)
        self.driver.get(
            'https://learn.acloud.guru/course/' + name + '/dashboard')
        time.sleep(4)

        response = BeautifulSoup(self.driver.page_source, 'html.parser')
        #print(response.prettify())
        URL_REGEX = re.compile("\/(course\/[^\"]*)")
        links = re.findall(URL_REGEX, str(response))

        simplecnt = 0
        for lnk in links:
            if "watch" in lnk:
                self.driver.get(
                    'https://learn.acloud.guru/' + lnk)
                time.sleep(3)
                response = BeautifulSoup(self.driver.page_source, 'html.parser')
                URL_REGEX = re.compile("(https://content.acloud.guru\/[^\"]*)")
                link = re.findall(URL_REGEX, str(response))
                link = link[0].replace(';','&')
                print(link)
                simplecnt+=1

                with requests.get(link, stream=True) as r:
                    r.raise_for_status()
                    with open((str(simplecnt)+".mp4"), 'wb') as f:
                        for chunk in r.iter_content(chunk_size=8192):
                            f.write(chunk)
        self.driver.quit()

LinuxAcademy()
